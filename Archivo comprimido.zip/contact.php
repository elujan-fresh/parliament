<section class="subscribe">
    <div class="subscribe-pitch">
      <h3>Parliament</h3>
      <p>324 West Chicago Ave. 
      	<br> 
      	Chicago IL 60654 
      	<br> 
      	<a class="mail" href="mailto:events@parliamentchicago.com?subject=Private Party Request from ParliamentChcago.com">events@parliamentchicago.com</a>
      	<br> 
      	Phone: 312.380.0004 <p>
    </div>
    <form action="MAILTO:cefuentes@narrowcastdigital.com" method="post" class="subscribe-form" enctype="text/plain">
	      <input type="name" name="name" class="subscribe-input" placeholder="Name" autofocus>
	      <br>
	      <input type="email" name="email" class="subscribe-input" placeholder="Email address" autofocus>
	      <br>
	      <input type="subject" name="subject" class="subscribe-input" placeholder="Subject" autofocus>
	      <br>
	      <textarea name="comments" class="subscribe-input" placeholder="Comments"></textarea>
		 <br>
	     <button class="reservation-submit" type="submit"></button>
     </form>
     
  </section>


  <!-- Responsive iFrame -->
<div class="Flexible-container">
    <iframe width="425" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com.mx/maps?ie=UTF-8&q=parliament+chicago&fb=1&gl=mx&hq=parliament&hnear=0x880e2c3cd0f4cbed:0xafe0a6ad09c0c000,Chicago,+IL,+USA&cid=0,0,7181962969688089317&ei=0ONmUoGeC8Wt2AWa1oCwCQ&sqi=2&ved=0CDIQrwswAQ&output=embed&amp;iwloc=near"></iframe>
</div