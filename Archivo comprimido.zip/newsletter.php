<section class="subscribe">
    <div class="subscribe-pitch">
      <h3>Subscribe</h3>
      <p>Subscribe to our newsletter to get the latest scoop right to your inbox.<p>
    </div>
    <form action="MAILTO:cefuentes@narrowcastdigital.com" method="post" class="subscribe-form" enctype="text/plain">
      <input type="email" name="email" class="subscribe-input" placeholder="Email address" autofocus>
      <button type="submit" class="subscribe-submit">Subscribe</button>
    </form>
  </section>